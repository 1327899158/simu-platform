App({
  globalData: {},
});
